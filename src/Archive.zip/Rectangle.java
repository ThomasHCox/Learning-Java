public class Rectangle {

	private int mLength;
	private int mWidth;
	private static String mName;

	public Rectangle(int length, int width) {
		mLength = length;
		mWidth = width;
	}

	public int getLength() {
		return mLength;
	}

	public void setLength(int length) {
		mLength = length;
	}

	public int getArea() {
		return mLength * mWidth;
	}

	public void setName(String name) {
		mName = name;
	}

	public String getName() {
		return mName;
	}
}
