public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// lessonOne();
		// lessonTwo();
		
		Rectangle rectangle1 = new Rectangle(10, 5);
		Rectangle rectangle2 = new Rectangle(20, 8);
		
		
		
	}

	public static void lessonTwo(){
		Rectangle rectangle1 = new Rectangle(10, 5);
		Rectangle rectangle2 = new Rectangle(20, 8);
		
		System.out.println(rectangle1.getLength());
		rectangle1.setLength(20);
		System.out.println(rectangle1.getLength());
		
		System.out.println("The area of your rectangle is "
				+ rectangle1.getArea());
		
		
		/* Create a second rectangle and print out which one has the larger area */
		rectangleComparison(rectangle1.getArea(), rectangle2.getArea());
		
	}
	
	public static void lessonOne() {
		int value1 = 3;
		int comparison1 = 10;
		int value2 = 3;
		int comparison2 = 100;
		int value3 = 3;
		int comparison3 = 1;

		comparison(value1, comparison1);
		comparison(value2, comparison2);
		comparison(value3, comparison3);

		int[] looping = new int[10];
		looping[0] = 3;
		looping[1] = 14;
		looping[2] = 15;
		looping[3] = 9;
		looping[4] = 26;
		looping[5] = 25;
		looping[6] = 29;
		looping[7] = 42;
		looping[8] = 266;
		looping[9] = 1;

		// for (lowest bound; highest bound; amount to increase by)
		for (int i = 0; i < (looping.length); i++) {
			System.out.println("This value is  " + looping[i]);

		}

	}

	public static void rectangleComparison(int rectangle1, int rectangle2) {
		if (rectangle1 < rectangle2) {
			System.out.println("The second rectangle passed has the larger area");
		} else if (rectangle1 > rectangle2) {
			System.out.println("The first rectangle passed has the larger area");
		} else {
			System.out.println("These are the same");
		}
	}
	
	
	public static void comparison(int value1, int comparison1) {
		if (value1 < comparison1) {
			System.out.println(value1 + " is less than " + comparison1);
			System.out.println("The difference between them is "
					+ (value1 - comparison1));
			System.out.println("The absolute value difference between them is "
					+ (comparison1 - value1));
		} else if (value1 > comparison1) {
			System.out.println(value1 + " is greater than " + comparison1);
			System.out.println("The difference between them is "
					+ (value1 - comparison1));
			System.out.println("The absolute value difference between them is "
					+ (value1 - comparison1));
		}
	}

}
